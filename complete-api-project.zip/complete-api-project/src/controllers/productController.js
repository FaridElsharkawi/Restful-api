const { validationResult } = require('express-validator');
const { run, get, all } = require('../config/db');

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const error = new Error('Validation failed');
    error.statusCode = 400;
    error.errors = errors.array();
    throw error;
  }
}

async function getProducts(req, res) {
  const products = await all(`
    SELECT products.*, users.name AS owner_name
    FROM products
    JOIN users ON users.id = products.owner_id
    ORDER BY products.id DESC
  `);

  res.json({ success: true, count: products.length, products });
}

async function getProduct(req, res) {
  const product = await get(`
    SELECT products.*, users.name AS owner_name
    FROM products
    JOIN users ON users.id = products.owner_id
    WHERE products.id = ?
  `, [req.params.id]);

  if (!product) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  res.json({ success: true, product });
}

async function createProduct(req, res) {
  handleValidation(req);

  const { name, description = '', price, stock = 0 } = req.body;
  const result = await run(
    'INSERT INTO products (name, description, price, stock, owner_id) VALUES (?, ?, ?, ?, ?)',
    [name, description, price, stock, req.user.id]
  );

  const product = await get('SELECT * FROM products WHERE id = ?', [result.id]);
  res.status(201).json({ success: true, product });
}

async function updateProduct(req, res) {
  handleValidation(req);

  const product = await get('SELECT * FROM products WHERE id = ?', [req.params.id]);
  if (!product) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  if (product.owner_id !== req.user.id) {
    return res.status(403).json({ success: false, message: 'You can only update your own products' });
  }

  const { name, description = '', price, stock = 0 } = req.body;
  await run(
    `UPDATE products
     SET name = ?, description = ?, price = ?, stock = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [name, description, price, stock, req.params.id]
  );

  const updatedProduct = await get('SELECT * FROM products WHERE id = ?', [req.params.id]);
  res.json({ success: true, product: updatedProduct });
}

async function deleteProduct(req, res) {
  const product = await get('SELECT * FROM products WHERE id = ?', [req.params.id]);
  if (!product) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  if (product.owner_id !== req.user.id) {
    return res.status(403).json({ success: false, message: 'You can only delete your own products' });
  }

  await run('DELETE FROM products WHERE id = ?', [req.params.id]);
  res.json({ success: true, message: 'Product deleted successfully' });
}

module.exports = { getProducts, getProduct, createProduct, updateProduct, deleteProduct };
