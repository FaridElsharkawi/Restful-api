const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const { run, get } = require('../config/db');

function createToken(userId) {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '7d' });
}

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const error = new Error('Validation failed');
    error.statusCode = 400;
    error.errors = errors.array();
    throw error;
  }
}

async function register(req, res) {
  handleValidation(req);

  const { name, email, password } = req.body;
  const existingUser = await get('SELECT id FROM users WHERE email = ?', [email]);

  if (existingUser) {
    return res.status(409).json({ success: false, message: 'Email already exists' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const result = await run(
    'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
    [name, email, hashedPassword]
  );

  const user = await get('SELECT id, name, email, created_at FROM users WHERE id = ?', [result.id]);
  const token = createToken(user.id);

  res.status(201).json({ success: true, token, user });
}

async function login(req, res) {
  handleValidation(req);

  const { email, password } = req.body;
  const user = await get('SELECT * FROM users WHERE email = ?', [email]);

  if (!user) {
    return res.status(401).json({ success: false, message: 'Invalid email or password' });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(401).json({ success: false, message: 'Invalid email or password' });
  }

  const token = createToken(user.id);
  delete user.password;

  res.json({ success: true, token, user });
}

async function me(req, res) {
  res.json({ success: true, user: req.user });
}

module.exports = { register, login, me };
