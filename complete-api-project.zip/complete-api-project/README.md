# Complete REST API Project

REST API كاملة باستخدام Node.js + Express + SQLite.

## Features

- Register / Login
- JWT Authentication
- Password hashing with bcrypt
- Products CRUD
- Request validation
- Global error handling
- SQLite database auto setup
- Protected routes

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

Server runs on:

```text
http://localhost:5000
```

## Endpoints

### Health

```http
GET /api/health
```

### Auth

```http
POST /api/auth/register
POST /api/auth/login
GET /api/auth/me
```

Register body:

```json
{
  "name": "Ahmed",
  "email": "ahmed@example.com",
  "password": "123456"
}
```

Login body:

```json
{
  "email": "ahmed@example.com",
  "password": "123456"
}
```

### Products

Public:

```http
GET /api/products
GET /api/products/:id
```

Protected, requires header:

```http
Authorization: Bearer YOUR_TOKEN
```

```http
POST /api/products
PUT /api/products/:id
DELETE /api/products/:id
```

Product body:

```json
{
  "name": "Laptop",
  "description": "Good laptop",
  "price": 15000,
  "stock": 10
}
```

## Project structure

```text
src/
  config/db.js
  controllers/authController.js
  controllers/productController.js
  middleware/auth.js
  middleware/errorHandler.js
  routes/authRoutes.js
  routes/productRoutes.js
  utils/asyncHandler.js
  app.js
  server.js
```
